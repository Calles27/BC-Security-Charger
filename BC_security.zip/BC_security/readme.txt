Hey, this is Calles27!

How to install - 
1. Drag " BCPS " into your resources folder.
2. add the line " start BCPS " to your server.cfg
3.Enjoy & report any bugs to the forum post!